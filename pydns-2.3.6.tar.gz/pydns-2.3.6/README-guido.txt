This directory contains a module (dnslib) that implements a DNS
(Domain Name Server) client, plus additional modules that define some
symbolic constants used by DNS (dnstype, dnsclass, dnsopcode).

Type "python dnslib.py -/" for a usage message.

You can also import dnslib and write your own, more sophisticated
client code; use the test program as an example (there is currently no
documentation :-).

--Guido van Rossum, CWI, Amsterdam <Guido.van.Rossum@cwi.nl>
URL:  <http://www.cwi.nl/cwi/people/Guido.van.Rossum.html>
